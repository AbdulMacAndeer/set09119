#pragma once
#pragma region Heading
// Math constants
#define _USE_MATH_DEFINES
#include <cmath>  
#include <random>
#include <iostream>
#include <numeric>

// Std. Includes
#include <string>
#include <time.h>

// GLM
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/matrix_operation.hpp>
#include "glm/ext.hpp"

// Other Libs
#include "SOIL2/SOIL2.h"

// project includes
#include "Application.h"
#include "Shader.h"
#include "Mesh.h"
#include "Body.h"
#include "Particle.h"
#include "Force.h"

// include 
using namespace std;

//Time
GLfloat deltaTime = 0.01f;
GLfloat lastFrame = 0.0f;

//Vars
int selection;
float amount;
//Scalar for room size
glm::vec3 boundScale = glm::vec3(5.0f);
//Vector that store particles
vector<Particle> particles;

//bool for task switching
bool planeOn = false;
#pragma endregion

#pragma region Methods
//Bool to string
inline const char * const BoolToString(bool b)
{
	return b ? "true" : "false";
}
// Random float
float randf(float lo, float hi)
{
	float random = ((float)rand()) / (float)RAND_MAX;
	float diff = hi - lo;
	float r = random * diff;
	return lo + r;
}
//Simplectic Euler integration
void integrate(Particle &par, float dt)
{
	//Calc new Velocity
	par.setVel(par.getVel() + par.getAcc() * dt);
	//Translate
	par.translate(par.getVel() * dt);
}
//Forward Euler integration
void integrateForward(Particle &par, float dt)
{
	//Get prev Velocity
	glm::vec3 preVel = par.getVel();
	//Calc velocity
	par.setVel(par.getVel() + dt * par.getAcc());
	par.translate(dt * preVel);
}

//Find location in circle
bool isInsideCircle(int rad, Particle &par)
{
	// Compare radius of circle with distance of its center from given point 
	if ((par.getPos().x - 0.0f) * (par.getPos().x - 0.0f) + (par.getPos().y - 0.0f) * (par.getPos().y - 0.0f) <= rad * rad)
		return true;
	else
		return false;
}
//Returns true if the Particle is in the object
bool isInsideCone(glm::vec3 coneTipPosition, glm::vec3 coneCenterLine, Particle &par, float FOVRadians, float height)
{
	//Get the difference vector
	glm::vec3 difference = par.getPos() - coneTipPosition;
	//dot product for projection
	double result = glm::dot(coneCenterLine, difference);
	//if in the view/angle from the origin of the cone
	if (result > cos(FOVRadians))
		return true;
	else
		return false;
}
//handles detecting collisions with bounds and reversing velocity of particle 
void roomCollision(Mesh &bounds, Particle &par)
{
	//Get the corners of the bounds cube in a vec
	glm::vec3 corner;
	for (int axis = 0; axis < 3; axis++)
	{
		corner[axis] = (bounds.getPos()[axis] + 0.5f*boundScale[axis]);
	}
	//for each x,y,z in particle and bounds
	for (int j = 0; j < 3; j++)
	{
		//if particles x,y,z is further than bounds
		if (par.getPos()[j] >= corner[j])
		{
			//Get the current position
			glm::vec3 prevPos = par.getPos();
			//Set axis in contact to corners position
			prevPos[j] = corner[j] - 0.05f;
			//get velocity
			glm::vec3 prevVel = par.getVel();
			//reverse velocity of axis
			prevVel[j] = -par.getVel()[j];
			//apply the change to position vector
			par.setPos(prevPos);
			par.setVel(prevVel);
		}
		//if particles x,y,z is less than bounds - boundScale[j];
		else if (par.getPos()[j] <= (corner[j] - boundScale[j]))
		{
			//Get the current position
			glm::vec3 prevPos = par.getPos();
			//Set axis in contact to corners position
			prevPos[j] = corner[j] - boundScale[j] + 0.05f;
			//get velocity
			glm::vec3 prevVel = par.getVel();
			//reverse velocity of axis
			prevVel[j] = -par.getVel()[j];
			//apply the change to position vector
			par.setPos(prevPos);
			par.setVel(prevVel);
		}
	}
}
#pragma endregion

// main function
int main()
{
	//Create application
	Application app = Application::Application();
	app.initRender();
	Application::camera.setCameraPosition(glm::vec3(0.0f, 5.0f, 15.0f));

	cout << "Press Space bar to turn on ground plane and it's collision detection" << endl;

	//Time Stuff
	GLfloat firstFrame = (GLfloat)glfwGetTime();
	double time = 0.0f;
	double dt = 0.01f;
	double currentTime = (double)glfwGetTime();
	double timeAccumulator = 0.0f;

	//Spring forces
	float stiff = 10.0f;
	float damper = 2.0f;
	float rest = 1.0f;

	//Gravity
	Gravity* g = new Gravity(glm::vec3(0.0f, -9.8f, 0.0f));

	//Shaders
	Shader lambert = Shader("resources/shaders/physics.vert", "resources/shaders/physics.frag");
	Shader transparent = Shader("resources/shaders/physics.vert", "resources/shaders/solid_transparent.frag");
	Shader greenShader = Shader("resources/shaders/solid.vert", "resources/shaders/solid_green.frag");
	Shader redShader = Shader("resources/shaders/solid.vert", "resources/shaders/solid_red.frag");
	Shader blueShader = Shader("resources/shaders/solid.vert", "resources/shaders/solid_blue.frag");

	//Create ground plane mesh
	Mesh plane = Mesh::Mesh(Mesh::QUAD);
	//Scale it up x5
	plane.scale(boundScale);
	//Apply Shader
	plane.setShader(lambert);

	//Create a room for collision
	Mesh bounds = Mesh::Mesh("resources/models/cube.obj");
	bounds.translate(glm::vec3(0.0f, 2.5f, 0.0f));
	bounds.scale(boundScale);
	bounds.setShader(transparent);

	//Start and End Particles
	Particle startParticle = Particle::Particle();//create object
	Particle endParticle = Particle::Particle();//create object
	startParticle.setPos(glm::vec3(-5.0f, 8.0f, 0.0f));//Set position
	endParticle.setPos(glm::vec3(5.0f, 8.0f, 0.0f));//Set position
	startParticle.rotate((GLfloat)M_PI_2, glm::vec3(1.0f, 0.0f, 0.0f));//Rotate
	endParticle.rotate((GLfloat)M_PI_2, glm::vec3(1.0f, 0.0f, 0.0f));//Rotate
	startParticle.getMesh().setShader(blueShader);//Set Shader
	endParticle.getMesh().setShader(blueShader);//Set Shader

	//Set Particle amount
	amount = 10;
	//Add start partical to array
	particles.push_back(startParticle);

	//Create the particles
	for (int i = 1; i < amount; i++)
	{
		//Move array pointer with new particle
		particles.push_back(Particle());
		//Translate - x on previos, space on y
		particles[i].setPos(glm::vec3(particles[i - 1].getPos().x + 1.0f, startParticle.getPos().y, 0.0f));
		//Rotate
		particles[i].rotate((GLfloat)M_PI_2, glm::vec3(1.0f, 0.0f, 0.0f));
		//apply shader
		particles[i].getMesh().setShader(blueShader);
		//Initial Position/Velocity
		particles[i].setVel(glm::vec3(0.0f));
	}

	//Add end partical to array
	particles.push_back(endParticle);

	//Add hookes to particles for chain hanging
	for (int i = 1; i < amount; i++)
	{
		//Apply force
		particles[i].addForce(g);
		//Hooke to the left
		//Hookes Law (current body, prev body, ks, kd, rest)
		Hooke* fsdL = new Hooke(&particles[i], &particles[i + 1], stiff, damper, rest);
		particles[i].addForce(fsdL);
		//Hooke to the right
		//Hookes Law (current body, prev body, ks, kd, rest)
		Hooke* fsdR = new Hooke(&particles[i], &particles[i - 1], stiff, damper, rest);
		particles[i].addForce(fsdR);

		//cout << "Particle " << i << " hooke to Particle " << i - 1 << endl;

		//for last particle in chain, hooke to endparticle
		if (i > amount - 1)
		{
			//Hooke between particle 9 and end particle
			Hooke* fsdEnd = new Hooke(&particles[i], &endParticle, stiff, damper, rest);
			particles[i].addForce(fsdEnd);
			//cout << "Particle " << i << " hooke to Particle " << i + 1 << endl;
		}
	}

	//Add end partical to array
	//particles.push_back(endParticle);

#pragma region GameLoop
	// Game loop
	while (!glfwWindowShouldClose(app.getWindow()))
	{
		// Timekeeping
		GLfloat newTime = (double)glfwGetTime();
		GLfloat frameTime = newTime - currentTime;
		currentTime = newTime;

		timeAccumulator += frameTime;

		//speed control
		//currentTime *= 0.05f;

		// Do fixed updates while time available
		while (timeAccumulator >= dt)
		{
			/*
			**	INTERACTION
			*/
			if (app.keys[GLFW_KEY_SPACE])
			{
				if (!planeOn)
					planeOn = true;
				else
					planeOn = false;

				cout << "Ground Plane is " << BoolToString(planeOn) << endl;
				app.keys[GLFW_KEY_SPACE] = false;
			}
			// Manage interaction
			app.doMovement(dt);
			/*
			**	SIMULATION
			*/
			for (int i = 0; i < amount; i++)
			{
				//Calculate Acceleration
				particles[i].setAcc(particles[i].applyForces(particles[i].getPos(), particles[i].getVel(), time, dt));
				//Intergrate
				integrate(particles[i], dt);

				//If task 3
				if (planeOn)
				{
					//Check for collision
					if (particles[i].getPos().y < plane.getPos().y)
					{
						particles[i].setPos(glm::vec3(particles[i].getPos().x, plane.getPos().y, particles[i].getPos().z));
						particles[i].setVel(glm::vec3(particles[i].getVel().x, -particles[i].getVel().y, particles[i].getVel().z));
					}
				}
			}

			//update time step
			timeAccumulator -= dt;
			time += dt;
		}
		/*
		**	RENDER
		*/
		// clear buffer
		app.clear();

		// draw groud plane
		if (planeOn)
			app.draw(plane);

		// draw particles
		app.draw(startParticle.getMesh());//Top Particle

		for (Particle p : particles) //hanging particles
		{
			app.draw(p.getMesh());
		}

		//draw the bounds
		//app.draw(bounds);

		//Show
		app.display();

		//Debug - Console information
		//cout << 1.0f / frameTime << " fps" << endl;
	}
#pragma endregion

	app.terminate();

	return EXIT_SUCCESS;
}
